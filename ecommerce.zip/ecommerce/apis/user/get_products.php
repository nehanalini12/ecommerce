<?php
require_once "../../database.php";
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD']  === 'GET'){
    $input = json_decode(file_get_contents('php://input'), true);
    

    $sql = "SELECT * FROM products";
    $result = mysqli_query($conn, $sql);
    $products = [];

    if($result) {
        while($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
        echo json_encode(['success' => true, 'products' => $products]);
    }

}
mysqli_close($conn);
?>