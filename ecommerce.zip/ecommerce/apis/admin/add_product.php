<?php
require_once "../../database.php";
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD']  === 'POST'){
    $input = json_decode(file_get_contents('php://input'), true);
    
    $name = $input['name'] ?? '';
    $description = $input['description']?? '';
    $price = $input['price']?? 0;
    $quantity = $input['quantity']?? 0;
    $category = $input['category']?? '';

    if(empty($name) || empty($description) || empty($price) || empty($quantity) || empty($category)){
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO products (name, description, price, quantity, category) VALUES (?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt, "ssdss", $name, $description, $price, $quantity, $category);
    $success = mysqli_stmt_execute($stmt);
    echo json_encode(['success' => $success, 'message' => $success? 'Product added successfully.' : 'Failed to add product.']); 

} else {
    http_response_code(405);
    echo json_encode(['success' => false,'message' => 'Invalid request method. Only POST is allowed.']);
}
mysqli_close($conn);
?>