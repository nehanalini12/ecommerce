<?php
require_once "../../database.php";
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD']  === 'POST'){
    $productId = $_POST['id'] ?? null;

    if($productId === null) {
        echo json_encode(['success' => false,'message' => 'Product ID is missing.']);
        exit;
    }

    if(!is_numeric($productId)){
        echo json_encode(['success' => false,'message' => 'Product ID is not a valid number.']);
        exit;
    }

    $stmt = mysqli_prepare($conn, "DELETE FROM products WHERE id =?");
    mysqli_stmt_bind_param($stmt, "i", $productId);
    $success = mysqli_stmt_execute($stmt);

    if($success){
        header("Location: ../../admin/admin_dashboard.php?message=Product+deleted+successfully.");
    } else {
        header("Location: ../../admin/admin_dashboard.php?message=Failed+to+deleted+product.");
    }
    exit;
} else {
    header("Location: ../../admin/admin_dashboard.php?message=Method+Not+Allowed.");
    exit;
}
mysqli_close($conn);