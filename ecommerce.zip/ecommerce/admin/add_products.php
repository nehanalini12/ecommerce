<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    die();
}

// //! Database connection 
// require_once "../database.php";
// if(isset($_POST['submit'])){
//     $name = $_POST['name'];
//     $description = $_POST['description'];
//     $price = $_POST['price'];
//     $quantity = $_POST['quantity'];
//     $category = $_POST['category'];

//     $errors = [];
//     if(empty($name) || empty($description) || empty($price) || empty($quantity) || empty($category)){
//         $errors[] = 'All fields are required.';

//     }

//     if(count($errors) === 0){
//         $stmt = mysqli_prepare($conn, "INSERT INTO products (name, description, price, quantity, category) VALUES (?,?,?,?,?)");
//         mysqli_stmt_bind_param($stmt, "ssdss", $name, $description, $price, $quantity, $category);
//         mysqli_stmt_execute($stmt);
//         echo "<div class='alert alert-success'>Product added successfully!</div>";
//     } else {
//         foreach($errors as $error){
//             echo "<div class='alert alert-danger'>$error</div>";
//         }

//     }
// }

$message = '';
if (isset($_POST['submit'])) {
    // GeT form data
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $category = $_POST['category'];

    // Validate form data:
    if (empty($name) || empty($description) || empty($price) || empty($quantity) || empty($category)) {
        $message = '<div class="alert alert-danger">All fields are required.</div>';
    } else {
        $data = [
            'name' => $name,
            'description' => $description,
            'price' => (float)$price,
            'quantity' => (int)$quantity,
            'category' => $category
        ];

        // Initialize cURL:
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "http://localhost/ecommerce/apis/admin/add_product.php");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

        $response = curl_exec($ch);

        if($response === false){
            $message = '<div class="alert alert-danger">Failed to add product. Please try again later.</div>';
        } else {
            $result = json_decode($response, true);

            // check if the response is valid JSON 
            if(is_array($result) && isset($result['success'])  && isset($result['message'])){
                if($result['success']){
                    $message = '<div class="alert alert-success">'.$result['message'].'</div>';
                } else {
                    $message = '<div class="alert alert-danger">'.$result['message'].'</div>';
                }
            } else {
                $message = '<div class="alert alert-danger">Un expected response from api.</div>';
            }

        }
        curl_close($ch);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Products</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <h2>Add products</h2>
    <!-- display message -->
     <?php if($message) echo $message; ?>
    <form action="add_products.php" method="post">
        <div class="form-group">
            <label for="name">Product Name:</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Product Name" required>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea type="text" name="description" class="form-control" placeholder="Enter Product Desc" required></textarea>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" name="price" step="0.01" class="form-control" placeholder="Enter Product Name" required>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" class="form-control" placeholder="Enter Product Name" required>
        </div>
        <div class="form-group">
            <label for="category">Category:</label>
            <select name="category" class="form-control" required>
                <option value="Electronics">Electronics</option>
                <option value="Books">Books</option>
                <option value="Home">Home</option>
                <option value="Clothing">Clothing</option>
            </select>
        </div>
        <button type="submit" name="submit" class="btn btn-primary mt-2">Add Product</button>
    </form>

    <div class="mt-3 mb-3">
        <a href="admin_dashboard.php" class="btn btn-secondary">
            Go Back to Dashboard
        </a>
    </div>
</body>

</html>