<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    die();
}

// display all the products
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost/ecommerce/apis/user/get_products.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$products = json_decode($response, true);
if (!$products['success']) {
    $products['products'] = [];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <section class="container">
        <h1>Welcome to Admin Dashboard</h1>
        <!-- Add new products -->
        <div class="mt-3 mb-3">
            <a href="./add_products.php" class="btn btn-primary">
                Add New Product
            </a>
        </div>

        <!-- List all the products -->
        
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Category</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products['products'] as $product): ?>
                <tr>
                        <td><?php echo $product['id'];?></td>
                        <td><?php echo $product['name'];?></td>
                        <td><?php echo $product['description'];?></td>
                        <td><?php echo $product['price'];?></td>
                        <td><?php echo $product['quantity'];?></td>
                        <td><?php echo $product['category'];?></td>
                        <td>
                            <!-- DELETE FORM -->
                             <form action="../apis/admin/delete_product.php" method="post">
                                <input type="hidden" name="id" value="<?php echo $product['id'];?>">
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach;?>
            </tbody>
        </table>


        <!-- Logout -->
        <a href="../logout.php" class="btn btn-dark">Logout</a>
    </section>
</body>

</html>