<?php
$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "ecommerce";

// conecting to the mysql server
$conn = mysqli_connect($hostName, $dbUser, $dbPassword);
if (!$conn) {
    die("Something went wrong!" . mysqli_connect_error());
}

// Create a Database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $dbName";
$databaseCreated = false;
if (mysqli_query($conn, $sql)) {
    $databaseCreate = mysqli_affected_rows($conn) > 0;
}

// Connect to the database
mysqli_select_db($conn, $dbName);

// SQL to Create users table if doesn't exists
$createTable = "
        CREATE TABLE IF NOT EXISTS users (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('user', 'admin') DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ";
$tableCreated = false;
if (mysqli_query($conn, $createTable)) {
    $tableCreated = mysqli_affected_rows($conn) > 0;
}

// Insert default admin if it doesnot exist
$adminUsername = 'admin@gmail.com';
$adminPassword = password_hash('admin@12345', PASSWORD_DEFAULT);
$checkAdmin = "SELECT * FROM users WHERE email = '$adminUsername' AND role = 'admin'";
$result = mysqli_query($conn, $checkAdmin);

if (mysqli_num_rows($result) == 0) {
    $inserAdmin = "
            INSERT INTO users (full_name, email, password, role)
            VALUES ('Admin', '$adminUsername', '$adminPassword', 'admin');
        ";
    mysqli_query($conn, $inserAdmin);
    echo "Admin created successfully";
}

if ($databaseCreate) {
    echo "database created successfully";
} elseif ($tableCreated) {
    echo "table created successfully";
}
// PRODUCTS TABLE CREATING
$createProductsTable = "
        CREATE TABLE IF NOT EXISTS products (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            price DECIMAL(10, 2) NOT NULL,
            quantity INT(11) NOT NULL,
            category VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
";

mysqli_query($conn, $createProductsTable);

?>