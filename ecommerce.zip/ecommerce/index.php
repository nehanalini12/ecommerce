<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    die();
}

// Check if user has admin role
$userRole = $_SESSION['user']['role'];
if ($userRole === 'admin') {
    header("Location: admin/admin_dashboard.php");
    die();
}

$fullName = $_SESSION['user']['full_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" 
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section class="container">
        <h1>Welcome, <?php echo htmlspecialchars($fullName) ?></h1>
        <!--products view  -->
        <?php include './view_products.php'; ?>


        <a href="logout.php" class="btn btn-dark">Logout</a>
    </section>
</body>

</html>