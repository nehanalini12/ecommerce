<?php

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://localhost/ecommerce/apis/user/get_products.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);


    $products = json_decode($response,true);

    if(!$products['success']){
        echo "<div class='alert alert-danger'>Failed to load all products</div>";
        $products['products'] = [];
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of all products</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" 
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <h2>List of Products:</h2>
    <div class="row">
        <?php foreach ($products['products'] as $product) :?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $product['name'];?></h5>
                        <p class="card-text"><?php echo $product['description'];?></p>
                        <p class="card-text">$<?php echo $product['price'];?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <p class="card-text"><?php echo $product['quantity'];?></p>
                            <p class="card-text">$<?php echo $product['category'];?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach;?></div>

    </div>
</body>
</html>