<?php
    session_start();

    if(isset($_SESSION["user"])){
        print_r($_SESSION["user"]);
        header("Location: index.php");
        die();
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <h2 class="h4">Login</h2>
        <?php
            if(isset($_POST['login'])){
                $email = $_POST['email'];
                $password = $_POST['password'];

                // exist in database or not
                require_once "database.php";
                $sql = "SELECT * FROM users WHERE email = '$email'";
                $result = mysqli_query($conn, $sql); // object -> array
                $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
                if($user){
                    // verify pass
                    if(password_verify($password, $user['password'])){
                        
                        // session after success
                        // $_SESSION["user"] = $user['id'];
                        $_SESSION['user'] = [
                            'id' => $user['id'],
                            'full_name' => $user['full_name'],
                            'email' => $user['email'], 
                            'role' => $user['role'],
                        ];
                        //login success
                        header("Location: index.php");
                        die();
                    } else {
                        echo "<div class='alert alert-danger'>Password does not match!</div>";
                    }
                } else {
                    echo "<div class='alert alert-danger'>Email does not match!</div>";
                }
            }
        ?>
        <form action="login.php" method="post">
        <div class="form-element">
                <input class="form-control" type="email" name="email" placeholder="Enter Your Email">
            </div>
            <div class="form-element">
                <input class="form-control" type="password" name="password" placeholder="Enter Your Password">
            </div>
            <div class="form-element">
                <input class="btn btn-primary" type="submit" name="login" value="Login">
            </div>
        </form>
        <div><p>Not Registered yet? <a href="registration.php">Register</a></p></div>
    </div>
</body>

</html>