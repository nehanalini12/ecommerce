<?php
    // $request = $_SERVER['REQUEST_METHOD']; //get method name
    // print($request);

    // php = curl
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, "https://dummyjson.com/products");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $response = curl_exec($ch);

    if($response === FALSE){
        die("cURL error" . curl_error($ch));
    }

    curl_close($ch);

    $products = json_decode($response, true);

    // Check if products are available
    if(!empty($products["products"])){
        $products = $products["products"];
    } else{
        die("No products found.");
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Products</h1>
    <div>
        <?php foreach($products as $item){?>
            <div>
                <img src="<?php echo $item['thumbnail']?>" 
                alt="<?php echo $item['title']?>">

                <h3><?php echo $item['title']?></h3>
                <p>&#8377;<?php echo $item['price']?></p>
            </div>
        <?php } ?>

    </div>
</body>
</html>